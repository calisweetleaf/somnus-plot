// Real wheels, a real compiled CPython extension, a real target interpreter and real processes; no mocks.
// Fixture prerequisites: python3 with venv, cc and Python.h (C extension). The default target runtime is a
// --without-pip venv over host python3, labelled shallow-host (contracts §11); PLOT_TEST_OWNED_PYTHON adds
// an owned-runtime native check. Every acceptance install consumes a plan emitted by planWheels or the
// cartographer; hand-built or hand-edited plans appear only in refusal cases. Nothing invokes pip or
// ensurepip, and this suite writes nothing under evidence/.
import * as fs from 'node:fs';
import * as path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {deflateRawSync,crc32} from 'node:zlib';
import {createHash} from 'node:crypto';
import {python as hostPython,wheels as helperWheels,tar,command} from './helpers.mjs';
import {verifyWheel,installWheels,assembleFromBank,planWheels,targetIdentity,readZip} from '../capabilities/assembler.mjs';
import {planClosure} from '../capabilities/cartographer.mjs';
import {openPlot} from '../main.js';
const base=path.resolve(new URL('..',import.meta.url).pathname),module=path.join(base,'capabilities/assembler.mjs'),cartographer=path.join(base,'capabilities/cartographer.mjs'),node=process.execPath;
const tmp=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'plot-assembler-'))),checks=[],timings={};
const SHALLOW='shallow-host',OWNED='owned';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const ms=t=>+(performance.now()-t).toFixed(2);
const test=async(name,fn,runtime)=>{const t=performance.now(),tag=runtime?` [runtime ${runtime}]`:'';try{const evidence=await fn();checks.push({name,passed:true,ms:ms(t),...(runtime?{runtime}:{}),...(evidence?{evidence}:{})});console.log('PASS '+name+tag)}catch(e){checks.push({name,passed:false,...(runtime?{runtime}:{}),error:e.stack});console.error('FAIL '+name+tag+'\n'+e.stack)}};
const dir=(...p)=>{let d=path.join(tmp,...p);fs.mkdirSync(d,{recursive:true});return d};
const run=(cmd,args,o={})=>spawnSync(cmd,args,{encoding:'utf8',timeout:60000,...o});
const ok=r=>{if(r.error||r.status!==0)throw Error(`exit ${r.status} ${r.signal||''} ${r.error?.message||''}\n${r.stdout}\n${r.stderr}`);return r.stdout.trim()};
const py=(exe,layer,code)=>ok(run(exe,['-I','-S','-c',`import sys;sys.path.insert(0,${JSON.stringify(layer)})\n${code}`]));
const rejects=(fn,code,re)=>{let e;try{fn()}catch(x){e=x}assert.ok(e,'expected rejection '+code);assert.equal(e.code,code,e.message);if(re)assert.match(e.message,re);return e};
const noGrave=root=>assert.ok(!fs.existsSync(path.join(root,'.grave')),'rejection wrote under '+root);
const digest=d=>createHash('sha256').update(d).digest('base64url');
function zip(file,entries){let parts=[],central=[],off=0;
 for(let e of entries){let name=Buffer.from(e.name),data=Buffer.from(e.data??''),method=e.method??8,body=method===8?deflateRawSync(data):data,crc=crc32(data),usize=e.usize??data.length,flags=/[^\x00-\x7f]/.test(e.name)?0x800:0;
  let h=Buffer.alloc(30);h.writeUInt32LE(0x04034b50,0);h.writeUInt16LE(20,4);h.writeUInt16LE(flags,6);h.writeUInt16LE(method,8);h.writeUInt16LE(0x21,12);h.writeUInt32LE(crc,14);h.writeUInt32LE(body.length,18);h.writeUInt32LE(usize,22);h.writeUInt16LE(name.length,26);
  let c=Buffer.alloc(46);c.writeUInt32LE(0x02014b50,0);c.writeUInt16LE(0x0314,4);c.writeUInt16LE(20,6);c.writeUInt16LE(flags,8);c.writeUInt16LE(method,10);c.writeUInt16LE(0x21,14);c.writeUInt32LE(crc,16);c.writeUInt32LE(body.length,20);c.writeUInt32LE(usize,24);c.writeUInt16LE(name.length,28);c.writeUInt32LE(((e.mode??0o100644)*65536)>>>0,38);c.writeUInt32LE(off,42);
  parts.push(h,name,body);central.push(c,name);off+=30+name.length+body.length}
 let cd=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(cd.length,12);end.writeUInt32LE(off,16);
 fs.writeFileSync(file,Buffer.concat([...parts,cd,end]));return file}
const csvField=s=>/[,"]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;
function wheel(at,{name,version='1.0',tag='py3-none-any',files={},entry,requires=[],purelib=true,modes={},record,extra=[],tamper,filename}){
 let dist=name.replace(/[-.]/g,'_'),di=`${dist}-${version}.dist-info`,[a,b,c]=tag.split('-'),tags=a.split('.').flatMap(x=>b.split('.').flatMap(y=>c.split('.').map(z=>x+'-'+y+'-'+z)));
 let all={...files,[di+'/METADATA']:`Metadata-Version: 2.1\nName: ${name}\nVersion: ${version}\n`+requires.map(r=>'Requires-Dist: '+r+'\n').join(''),[di+'/WHEEL']:`Wheel-Version: 1.0\nGenerator: plot-assembler-test\nRoot-Is-Purelib: ${purelib}\n`+tags.map(t=>'Tag: '+t+'\n').join('')};
 if(entry)all[di+'/entry_points.txt']=entry;
 let rows=Object.entries(all).map(([k,v])=>`${csvField(k)},sha256=${digest(Buffer.from(v))},${Buffer.byteLength(v)}`);rows.push(di+'/RECORD,,');
 let entries=[...Object.entries(all).map(([k,v])=>({name:k,data:v,mode:modes[k]})),...(record===null?[]:[{name:di+'/RECORD',data:record?record(rows,di):rows.join('\n')+'\n'}]),...extra];
 if(tamper)tamper(entries,di);return zip(path.join(at,filename||`${dist}-${version}-${tag}.whl`),entries)}
function tree(d){let out={};(function rec(x,r){let st=fs.lstatSync(x);out[r||'.']={mode:st.mode,mtime:st.mtimeMs,size:st.size,...(st.isFile()?{sha256:createHash('sha256').update(fs.readFileSync(x)).digest('hex')}:{})};if(st.isDirectory())for(let n of fs.readdirSync(x).sort())rec(path.join(x,n),r?r+'/'+n:n)})(d,'');return out}
function chmodTree(d,writable){for(let n of fs.readdirSync(d)){let x=path.join(d,n);if(fs.statSync(x).isDirectory())chmodTree(x,writable);else fs.chmodSync(x,writable?0o644:0o444)}fs.chmodSync(d,writable?0o755:0o555)}
function installedRecord(layer,di){for(let [p,h,s] of fs.readFileSync(path.join(layer,di,'RECORD'),'utf8').trim().split('\n').map(l=>l.match(/("([^"]|"")*"|[^,]*)/g).filter((_,i)=>i%2===0).map(f=>f.startsWith('"')?f.slice(1,-1).replace(/""/g,'"'):f))){if(p===di+'/RECORD')continue;let d=fs.readFileSync(path.join(layer,p));assert.equal(h,'sha256='+digest(d),'installed RECORD '+p);assert.equal(+s,d.length)}}
// Code-emitted wheel plan, then assembly from it.
const planned=(bank,requirements,target=rtpy)=>{let p=planWheels({bank,target,requirements});assert.equal(p.ok,true,JSON.stringify(p.diagnostics));return p};
const assembled=(root,bank,requirements,id,target=rtpy)=>assembleFromBank({root,bank,plan:planned(bank,requirements,target),target,id});
const bankWith=(name,...files)=>{let d=dir('banks',name);for(let f of files)fs.copyFileSync(f,path.join(d,path.basename(f)));return d};
const NATIVE_C='#include <Python.h>\nstatic PyObject *value(PyObject*s,PyObject*a){return PyLong_FromLong(37);}\nstatic PyMethodDef methods[]={{"value",value,METH_NOARGS,"real fixture"},{NULL,NULL,0,NULL}};\nstatic struct PyModuleDef module={PyModuleDef_HEAD_INIT,"plot_native",NULL,-1,methods};\nPyMODINIT_FUNC PyInit_plot_native(void){return PyModule_Create(&module);}\n';

// Fixture prerequisites and the shallow-host target runtime.
const prereq={python3:!!hostPython,cc:run('sh',['-c','command -v cc']).status===0,pythonH:hostPython?run(hostPython,['-c','import sysconfig,os,sys;sys.exit(0 if os.path.exists(os.path.join(sysconfig.get_paths()["include"],"Python.h")) else 1)']).status===0:false};
console.log('fixture prerequisites '+JSON.stringify(prereq));
const runtime=path.join(tmp,'runtime');ok(run(hostPython,['-m','venv','--without-pip',runtime]));
const rtpy=path.join(runtime,'bin/python3'),target=targetIdentity(rtpy),plat=target.platforms.at(-1),cpTag=`${target.abi}-${target.abi}-${plat}`;
console.log(`runtime ${SHALLOW}: ${rtpy} (venv --without-pip over host ${hostPython}, Python ${target.version} ${target.soabi})`);
const wheels=dir('wheels'),suffix=command(hostPython,['-c','import sysconfig;print(sysconfig.get_config_var("EXT_SUFFIX"))']);
let helper=null,so=null;if(prereq.cc&&prereq.pythonH){helper=helperWheels(dir('helper'));so=fs.readFileSync(path.join(tmp,'helper','plot_native'+suffix))}
const pureFiles={'plot_pure/__init__.py':"import sys\nVERSION='1.0'\ndef main():\n    print('plot-pure',VERSION,sys.argv[1:])\n    return 3\ndef gui():\n    return 0\n",'plot_pure/res,comma.txt':'resource with a comma in its name'};
const pureEntry='[console_scripts]\nplot-pure = plot_pure:main\n[gui_scripts]\nplot-pure-gui = plot_pure:gui [extra]\n';
const pure=wheel(wheels,{name:'plot-pure',files:pureFiles,entry:pureEntry,extra:[{name:'plot_pure-1.0.dist-info/RECORD.jws',data:'{"signatures":[]}'}]});
const bankPure=bankWith('pure',pure);
const sample=(v,at=dir('bank-src'))=>wheel(at,{name:'plot-sample',version:v,files:{'plot_sample/__init__.py':`VERSION=${JSON.stringify(v)}\n`}});
const nativeWheel=at=>wheel(at,{name:'plot-native',tag:cpTag,purelib:false,files:{['plot_native'+suffix]:so},modes:{['plot_native'+suffix]:0o100755}});

await test('pure wheel: planWheels plan, assembled, importable with -I -S, reused',()=>{
 let t=performance.now(),v=verifyWheel(pure,rtpy);timings.verify_pure_ms=ms(t);
 assert.equal(v.selected,'py3-none-any');assert.equal(v.digests,5);assert.deepEqual(v.unhashed,[]);assert.deepEqual(v.signatures,[{file:'plot_pure-1.0.dist-info/RECORD.jws',state:'present-unverified',installed:false}]);
 t=performance.now();let plan=planned(bankPure,['plot-pure']);timings.plan_wheels_ms=ms(t);let n=plan.nodes[0];
 assert.equal(plan.schema,'plot.closure/1');assert.deepEqual(plan.order,['plot-pure@1.0']);assert.equal(n.source.integrity,'sha256-'+createHash('sha256').update(fs.readFileSync(pure)).digest('base64'));assert.deepEqual(n.entry.bin,{'plot-pure':'bin/plot-pure','plot-pure-gui':'bin/plot-pure-gui'});
 assert.deepEqual(plan.target.python.tags,target.tags);assert.equal(JSON.stringify(planWheels({bank:bankPure,target:rtpy,requirements:['plot-pure']})),JSON.stringify(plan),'deterministic');
 let root=dir('pure');t=performance.now();let o=assembleFromBank({root,bank:bankPure,plan,target:rtpy,id:'pure'});timings.install_pure_ms=ms(t);
 assert.equal(o.reused,false);assert.ok(o.path.startsWith(path.join(root,'.grave/objects/pure-')));
 let {reused,...stamp}=o;assert.deepEqual(read(path.join(o.path,'.plot.json')),stamp);assert.equal(stamp.python,undefined);assert.deepEqual(stamp.inputs,[{ref:'wheel:'+path.basename(pure),sha256:createHash('sha256').update(fs.readFileSync(pure)).digest('hex')}]);
 assert.equal(py(rtpy,o.path,"import plot_pure,importlib.metadata as m,importlib.resources as r;print(plot_pure.VERSION,m.version('plot-pure'),r.files('plot_pure').joinpath('res,comma.txt').read_text())"),'1.0 1.0 resource with a comma in its name');
 assert.ok(!fs.existsSync(path.join(o.path,'plot_pure-1.0.dist-info/RECORD.jws')));assert.equal(fs.readFileSync(path.join(o.path,'plot_pure-1.0.dist-info/INSTALLER'),'utf8'),'plot-assembler\n');
 installedRecord(o.path,'plot_pure-1.0.dist-info');assert.deepEqual(fs.readdirSync(path.join(root,'.grave')).sort(),['objects']);
 t=performance.now();let again=assembleFromBank({root,bank:bankPure,plan,target:rtpy,id:'pure'});timings.historical_reuse_ms=ms(t);
 assert.equal(again.reused,true);assert.equal(again.path,o.path);assert.equal(fs.readdirSync(path.join(root,'.grave/objects')).length,1);
 return {layer:o.path,bytes:v.bytes};
},SHALLOW);

await test('compatible C extension: planWheels selects the compatible build, importable by the target runtime with -I -S',()=>{
 if(!so)throw Error('fixture prerequisite missing: cc + Python.h '+JSON.stringify(prereq));
 let bank=dir('banks','native');nativeWheel(bank);wheel(bank,{name:'plot-native',tag:'cp27-cp27mu-linux_x86_64',purelib:false,files:{'plot_native.so':'not loadable'}});
 let plan=planned(bank,['plot-native==1.0']);assert.equal(path.basename(plan.nodes[0].source.path),`plot_native-1.0-${cpTag}.whl`);
 let root=dir('native'),t=performance.now(),o=assembleFromBank({root,bank,plan,target:rtpy,id:'native'});timings.install_native_ms=ms(t);
 assert.equal(o.wheels[0].tag,cpTag);assert.equal(fs.statSync(path.join(o.path,'plot_native'+suffix)).mode&0o777,0o755);
 assert.equal(py(rtpy,o.path,'import plot_native;print(plot_native.value(),plot_native.__file__.startswith(sys.path[0]))'),'37 True');
 assert.equal(ok(run(rtpy,['-I','-c','import importlib.util;print(importlib.util.find_spec("pip"))'])),'None','target runtime must not carry pip');
 let abi3=wheel(wheels,{name:'plot-abi',tag:`cp38-abi3-${plat}`,purelib:false,files:{'plot_abi.py':'x=1\n'}});assert.equal(verifyWheel(abi3,rtpy).selected,`cp38-abi3-${plat}`);
 return {tag:cpTag,soabi:target.soabi,glibc:target.glibc};
},SHALLOW);

await test('.data relocation: purelib, platlib, scripts with #!python rewrite, data, headers',()=>{
 let d='plot_data-1.0.data',bank=dir('banks','data');wheel(bank,{name:'plot-data',files:{'plot_data/__init__.py':'x=1\n',[d+'/purelib/plot_data_pure.py']:'P=1\n',[d+'/platlib/plot_data_plat.py']:'Q=2\n',[d+'/scripts/plot-data-tool']:"#!python -u\nimport sys,plot_data_pure\nprint('tool',sys.executable,plot_data_pure.P)\n",[d+'/data/share/plot/readme.txt']:'data',[d+'/headers/plot.h']:'#define PLOT 1\n'}});
 let o=assembled(dir('data'),bank,['plot-data'],'data'),L=o.path,tool=path.join(L,'bin/plot-data-tool');
 for(let f of ['plot_data_pure.py','plot_data_plat.py','data/share/plot/readme.txt','include/plot_data/plot.h'])assert.ok(fs.existsSync(path.join(L,f)),f);
 assert.ok(!fs.existsSync(path.join(L,d)));assert.equal(fs.statSync(tool).mode&0o777,0o755);assert.equal(fs.readFileSync(tool,'utf8').split('\n')[0],'#!'+rtpy+' -u');
 assert.equal(ok(run(tool,[],{env:{...process.env,PYTHONPATH:L}})),`tool ${rtpy} 1`);assert.equal(o.bin,path.join(L,'bin'));installedRecord(L,'plot_data-1.0.dist-info');
},SHALLOW);

await test('console and gui entrypoints runnable, exit status and argv preserved, sh trampoline for spaced interpreter',()=>{
 let L=checks[0].evidence?.layer;if(!L)throw Error('pure layer from check 1 unavailable');
 let r=run(path.join(L,'bin/plot-pure'),['one','two']);assert.equal(r.status,3,r.stderr);assert.equal(r.stdout.trim(),"plot-pure 1.0 ['one', 'two']");
 assert.equal(run(path.join(L,'bin/plot-pure-gui')).status,0);assert.equal(fs.readFileSync(path.join(L,'bin/plot-pure'),'utf8').split('\n')[0],'#!'+rtpy+' -IS');
 let exe=path.join(dir('with space'),'python3');fs.symlinkSync(rtpy,exe);
 let o=assembled(dir('spaced'),bankPure,['plot-pure==1.0'],'pure',exe),w=path.join(o.path,'bin/plot-pure');
 assert.match(fs.readFileSync(w,'utf8'),/^#!\/bin\/sh\n'''exec' /);r=run(w,['x']);assert.equal(r.status,3,r.stderr);assert.equal(r.stdout.trim(),"plot-pure 1.0 ['x']");
},SHALLOW);

await test('malformed RECORD and digest/size mismatches rejected with no write',()=>{
 let at=dir('bad-record'),f='p/__init__.py',files={[f]:'x=1\n'},n=0,cases=[
  [{tamper:e=>{e.find(x=>x.name===f).data='x=2\n'}},'RECORD',/sha256 digest mismatch/],
  [{record:r=>r.map(l=>l.startsWith(f)?l.replace(/,\d+$/,',99'):l).join('\n')},'RECORD',/size 4 disagrees with RECORD 99/],
  [{record:r=>r.filter(l=>!l.startsWith(f)).join('\n')},'RECORD',/not listed in RECORD/],
  [{record:r=>[...r,'p/ghost.py,sha256=AAAA,1'].join('\n')},'RECORD',/lists absent file p\/ghost.py/],
  [{record:r=>[...r,r[0]].join('\n')},'RECORD',/duplicate RECORD row/],
  [{record:r=>r.map(l=>l.startsWith(f)?f+',sha256,4':l).join('\n')},'RECORD',/malformed RECORD digest/],
  [{record:r=>r.map(l=>l.startsWith(f)?f+',md5=abc,4':l).join('\n')},'RECORD',/weak RECORD digest md5/],
  [{record:r=>r.map(l=>l.startsWith(f)?f+',crc32=abc,4':l).join('\n')},'RECORD',/unsupported RECORD digest crc32/],
  [{record:r=>r.join('\n')+'\n"p/x.py,sha256=a,1'},'RECORD',/unterminated RECORD quote/],
  [{record:r=>r.map(l=>l.startsWith(f)?l+',extra':l).join('\n')},'RECORD',/RECORD row with 4 fields/],
  [{record:null},'RECORD',/RECORD missing/],
  [{record:r=>r.map(l=>l.startsWith(f)?f+',,':l).join('\n')},'RECORD',/no RECORD digest/]];
 for(let [o,code,re] of cases){let w=wheel(at,{name:'bad-'+(++n),files,...o}),root=dir('bad-record-root',''+n);rejects(()=>installWheels({root,id:'bad',wheels:[w],target:rtpy}),code,re);noGrave(root)}
 let unhashed=wheel(at,{name:'plot-unhashed',files,record:r=>r.map(l=>l.startsWith(f)?f+',,':l).join('\n')});assert.deepEqual(verifyWheel(unhashed,rtpy,{allowUnhashed:true}).unhashed,[f]);
 if(helper){rejects(()=>verifyWheel(helper.one,rtpy),'RECORD',/no RECORD digest/);let v=verifyWheel(helper.one,rtpy,{allowUnhashed:true});assert.equal(v.name,'plot-sample');assert.equal(v.digests,0)}
 return {cases:cases.length,pythonZipfileInterop:!!helper};
});

await test('incompatible ABI, platform and python tags rejected before any write',()=>{
 let at=dir('abi'),f={'q.py':'x=1\n'},n=0;
 let cp311=path.join(at,`plot_old-1.0-cp311-cp311-${plat}.whl`);fs.writeFileSync(cp311,'not a zip archive: tags are checked before reading');
 for(let w of [cp311,wheel(at,{name:'plot-win',tag:`${target.abi}-${target.abi}-win_amd64`,files:f}),wheel(at,{name:'plot-py2',tag:'py2-none-any',files:f}),wheel(at,{name:'plot-glibc',tag:`${target.abi}-${target.abi}-manylinux_2_99_x86_64`,files:f})]){
  let root=dir('abi-root',''+(++n));rejects(()=>installWheels({root,id:'abi',wheels:[pure,w],target:rtpy}),'INCOMPATIBLE',/incompatible with target/);noGrave(root)}
 let root=dir('abi-root','meta'),lie=wheel(at,{name:'plot-lie',files:f,tamper:(e,di)=>{e.find(x=>x.name===di+'/WHEEL').data='Wheel-Version: 1.0\nRoot-Is-Purelib: true\nTag: cp27-cp27mu-linux_x86_64\n'},filename:'plot_lie-1.0-py3-none-any.whl'});
 rejects(()=>installWheels({root,id:'abi',wheels:[lie],target:rtpy}),'RECORD');
 let lie2=wheel(at,{name:'plot-lie2',files:f,record:(r,di)=>r.filter(l=>!l.startsWith(di+'/WHEEL')).concat(`${di}/WHEEL,,`).join('\n'),tamper:(e,di)=>{e.find(x=>x.name===di+'/WHEEL').data='Wheel-Version: 1.0\nRoot-Is-Purelib: true\nTag: cp27-cp27mu-linux_x86_64\n'}});
 rejects(()=>installWheels({root,id:'abi',wheels:[lie2],target:rtpy,allowUnhashed:true}),'METADATA',/WHEEL Tag lines disagree/);
 let wrongName=wheel(at,{name:'plot-name',files:f,filename:'plot_other-1.0-py3-none-any.whl'});rejects(()=>verifyWheel(wrongName,rtpy),'METADATA',/expected one .dist-info|does not match filename/);
 let closure=targetIdentity({version:'3.12.3',soabi:'cpython-312-x86_64-linux-gnu',tags:['cp312-cp312-linux_x86_64','py3-none-any']});assert.deepEqual(closure.tags,['cp312-cp312-linux_x86_64','py3-none-any']);
 rejects(()=>verifyWheel(wheel(at,{name:'plot-py312',tag:'py312-none-any',files:f}),closure),'INCOMPATIBLE');noGrave(root);
});

await test('traversal, symlink, special, duplicate entries and colliding destinations rejected',()=>{
 let at=dir('paths'),n=0,evil=path.join(tmp,'evil.py'),f={'p/a.py':'a=1\n'};
 let cases=[[{extra:[{name:'../evil.py',data:'x'}]},'PATH',/unsafe path/],[{extra:[{name:'/tmp/evil.py',data:'x'}]},'PATH',/unsafe path/],[{extra:[{name:'p\\..\\evil.py',data:'x'}]},'PATH',/unsafe path/],[{extra:[{name:'p/./a.py',data:'x'}]},'PATH',/unsafe path/],
  [{extra:[{name:'p/link',data:'../../../../evil.py',mode:0o120777}]},'PATH',/symlink entry p\/link rejected/],[{extra:[{name:'p/fifo',data:'',mode:0o010644}]},'PATH',/special file/],
  [{extra:[{name:'p/a.py',data:'b=2\n'}]},'PATH',/duplicate zip entry p\/a.py/],
  [{name:'plot-dup',files:{...f,'plot_dup-1.0.data/purelib/p/a.py':'b=2\n'}},'PATH',/duplicate destination p\/a.py/],
  [{files:{'p':'file\n','p/x.py':'x\n'}},'PATH',/both a file and a directory/],
  [{files:{'.plot.json':'{}'}},'PATH',/reserved destination/],
  [{name:'plot-bin',files:{...f,'plot_bin-1.0.data/scripts/tool':'#!python\n'},entry:'[console_scripts]\ntool = p.a:main\n'},'PATH',/duplicate destination bin\/tool/],
  [{entry:'[console_scripts]\n../x = p.a:main\n'},'ENTRY',/invalid entry point/]];
 for(let [o,code,re] of cases){let w=wheel(at,{name:'plot-path-'+(++n),files:f,...o}),root=dir('paths-root',''+n);rejects(()=>installWheels({root,id:'paths',wheels:[w],target:rtpy}),code,re);noGrave(root)}
 let one=wheel(at,{name:'plot-share-a',files:{'shared/x.py':'a\n'}}),two=wheel(at,{name:'plot-share-b',files:{'shared/x.py':'b\n'}}),root=dir('paths-root','cross');
 rejects(()=>installWheels({root,id:'paths',wheels:[one,two],target:rtpy}),'PATH',/duplicate destination shared\/x.py/);noGrave(root);
 assert.ok(!fs.existsSync(evil));return {cases:cases.length+1};
});

await test('extraction limits, declared-size lies and zip64 enforced',()=>{
 let at=dir('limits'),zeros=Buffer.alloc(4<<20),big=wheel(at,{name:'plot-big',files:{'z/zeros.bin':zeros,'z/a.py':'a\n','z/b.py':'b\n'}}),n=0;
 assert.ok(fs.statSync(big).size<64<<10,'fixture compresses');assert.equal(verifyWheel(big,rtpy).bytes>4<<20,true);
 for(let [limits,re] of [[{entries:3},/6 entries exceeds limit 3/],[{totalBytes:1<<20},/expanded size exceeds limit/],[{fileBytes:1024},/exceeds file limit 1024/],[{archiveBytes:64},/exceeds limit 64/]]){let root=dir('limits-root',''+(++n));rejects(()=>installWheels({root,id:'big',wheels:[big],target:rtpy,limits}),'LIMIT',re);noGrave(root)}
 let lie=wheel(at,{name:'plot-lie',files:{'z/zeros.bin':''},tamper:e=>{let x=e.find(y=>y.name==='z/zeros.bin');x.data=zeros;x.usize=16}});
 rejects(()=>verifyWheel(lie,rtpy),'ZIP',/expands beyond declared size/);
 let z64=path.join(at,'plot_z64-1.0-py3-none-any.whl'),b=fs.readFileSync(pure);b.writeUInt16LE(0xffff,b.length-12);b.writeUInt16LE(0xffff,b.length-14);fs.writeFileSync(z64,b);
 rejects(()=>readZip(z64),'ZIP',/zip64 unsupported/);
 let cut=path.join(at,'plot_cut-1.0-py3-none-any.whl');fs.writeFileSync(cut,fs.readFileSync(pure).subarray(0,200));rejects(()=>verifyWheel(cut,rtpy),'ZIP',/end of central directory/);
});

let bank=dir('bank');
await test('two plots assemble conflicting subsets from one read-only bank via planWheels; unsatisfiable plans fail closed; bank unmodified',()=>{
 for(let v of ['1.0','2.0'])fs.copyFileSync(sample(v),path.join(bank,`plot_sample-${v}-py3-none-any.whl`));
 fs.mkdirSync(path.join(bank,'native'));if(so)nativeWheel(path.join(bank,'native'));
 wheel(bank,{name:'plot-legacy',tag:'cp27-cp27mu-linux_x86_64',files:{'legacy.py':'x\n'}});
 wheel(bank,{name:'plot-app',files:{'plot_app.py':'import plot_sample\nV=plot_sample.VERSION\n'},requires:['plot-sample (<2)','plot-extra-dep ; extra == "x"','plot-win ; sys_platform == "win32"']});
 chmodTree(bank,false);let before=tree(bank);
 let A=dir('plot-a'),B=dir('plot-b'),t=performance.now(),planA=planned(bank,['plot-app',...(so?['plot_native']:[])]),a=assembleFromBank({root:A,bank,plan:planA,target:rtpy,id:'site'});timings.assemble_bank_ms=ms(t);
 assert.deepEqual(planA.order.filter(x=>x!=='plot-native@1.0'),['plot-sample@1.0','plot-app@1.0']);assert.deepEqual(planA.nodes.find(n=>n.id==='plot-app@1.0').deps,[{kind:'prod',name:'plot-sample',range:'(<2)',resolved:'plot-sample@1.0'}]);
 assert.deepEqual(planA.unsupported.map(u=>u.form),['plot-win ; sys_platform == "win32"']);
 t=performance.now();let planB=path.join(dir('plans'),'b.json'),pr=run(node,[module,'plan-wheels','--bank',bank,'--python',rtpy,'Plot.Sample>=1.5,!=3.0']);fs.writeFileSync(planB,ok(pr));
 let b=JSON.parse(ok(run(node,[module,'assemble','--root',B,'--bank',bank,'--plan',planB,'--python',rtpy,'--id','site'])));timings.cli_plan_and_assemble_ms=ms(t);
 assert.equal(py(rtpy,a.path,'import plot_app;print(plot_app.V)'),'1.0');assert.equal(py(rtpy,b.path,'import plot_sample;print(plot_sample.VERSION)'),'2.0');
 if(so)assert.equal(py(rtpy,a.path,'import plot_native;print(plot_native.value())'),'37');
 assert.notEqual(run(rtpy,['-I','-S','-c',`import sys;sys.path.insert(0,${JSON.stringify(b.path)});import plot_native`]).status,0);
 const bad=(reqs,code,re)=>{let p=planWheels({bank,target:rtpy,requirements:reqs});assert.equal(p.ok,false);assert.ok(p.diagnostics.some(d=>d.code===code&&re.test(d.detail)),JSON.stringify(p.diagnostics));rejects(()=>assembleFromBank({root:dir('plot-c'),bank,plan:p,target:rtpy}),'PLAN',/not ok/);return p};
 bad(['plot-sample>=3'],'range-unsatisfied',/no bank version satisfies/);bad(['plot-legacy'],'missing',/no wheel compatible/);bad(['plot-absent'],'missing',/not in bank/);
 bad(['plot-app','plot-sample==2.0'],'range-unsatisfied',/conflicts with selected/);assert.equal(bad(['plot-sample~=1.0'],'range-unsatisfied',/unsupported requirement/).unsupported[0].where,'requested');
 let cli=run(node,[module,'plan-wheels','--bank',bank,'--python',rtpy,'plot-legacy']);assert.equal(cli.status,1);assert.equal(JSON.parse(cli.stdout).ok,false);
 let e=rejects(()=>assembleFromBank({root:dir('plot-c'),bank,plan:['plot-legacy==1.0'],target:rtpy}),'ACQUISITION_REQUIRED',/no compatible wheel in bank/);assert.equal(e.requirement.sourceBuild,false);
 rejects(()=>assembleFromBank({root:dir('plot-c'),bank,plan:['plot-sample==1.0','plot-sample==2.0'],target:rtpy}),'CONFLICT');
 noGrave(path.join(tmp,'plot-c'));assert.deepEqual(tree(bank),before);
 return {a:a.wheels.map(w=>w.file),b:b.wheels.map(w=>w.file)};
},SHALLOW);

await test('interrupted assembly (SIGKILL after staging) is never adopted; retry publishes, then reuses',()=>{
 let root=dir('interrupt'),objects=path.join(root,'.grave/objects'),rt=path.join(objects,'python-AbC123');fs.mkdirSync(objects,{recursive:true});ok(run(hostPython,['-m','venv','--without-pip',rt]));
 let exe=path.join(rt,'bin/python3');fs.writeFileSync(path.join(rt,'.plot.json'),JSON.stringify({key:JSON.stringify([{python:{}},[process.platform,process.arch],[]]),path:rt,python:exe}));
 let planFile=path.join(dir('plans'),'interrupt.json');fs.writeFileSync(planFile,ok(run(node,[module,'plan-wheels','--bank',bankPure,'--python',exe,'plot-pure'])));
 let r=run(node,[module,'assemble','--root',root,'--bank',bankPure,'--plan',planFile,'--id','site','--python',exe],{env:{...process.env,PLOT_ASSEMBLER_CRASH:'staged'}});assert.equal(r.signal,'SIGKILL',r.stderr);
 let owner=read(path.join(root,'.grave/.lock/owner.json')),stage=owner.stages[0];assert.equal(owner.writer,'assembler');assert.ok(fs.existsSync(path.join(stage,'plot_pure/__init__.py')));assert.ok(!fs.existsSync(path.join(stage,'.plot.json')));
 let pins=fs.readdirSync(path.join(root,'.grave/pins'));assert.ok(pins.length>=1);for(let p of pins.map(x=>read(path.join(root,'.grave/pins',x)))){assert.equal(p.kind,'acquisition');assert.deepEqual(p.paths,[rt]);assert.equal(p.owner.pid,owner.pid)}
 let t=performance.now(),o=assembleFromBank({root,bank:bankPure,plan:planFile,target:exe,id:'site'});timings.retry_after_crash_ms=ms(t);
 assert.equal(o.reused,false);assert.notEqual(o.path,stage);assert.deepEqual(JSON.parse(o.key)[2],[rt]);assert.ok(!fs.existsSync(path.join(root,'.grave/.lock')));
 assert.ok(!fs.existsSync(path.join(stage,'.plot.json')),'unstamped stage stays unstamped');let archived=fs.readdirSync(path.join(root,'.grave/interrupted'));assert.equal(archived.length,1);assert.match(archived[0],/^acquisition-/);
 assert.equal(run(path.join(o.path,'bin/plot-pure')).status,3);assert.deepEqual(fs.readdirSync(path.join(root,'.grave/pins')),pins,'only the dead writer pins remain');
 let again=assembleFromBank({root,bank:bankPure,plan:planFile,target:exe,id:'site'});assert.equal(again.reused,true);assert.equal(again.path,o.path);
 fs.mkdirSync(path.join(root,'.grave/.lock'));fs.writeFileSync(path.join(root,'.grave/.lock/owner.json'),JSON.stringify({pid:process.pid,birth:null,stages:[]}));
 let e=rejects(()=>assembleFromBank({root,bank:bankPure,plan:planFile,target:exe,id:'other'}),'BUSY');assert.equal(e.retryable,true);fs.rmSync(path.join(root,'.grave/.lock'),{recursive:true});
 return {stage,published:o.path,deadPins:pins.length};
},SHALLOW);

await test('pin-then-validate: consumed runtime object pinned while read; tombstoned object refused retryably',()=>{
 let root=path.join(tmp,'interrupt'),rt=path.join(root,'.grave/objects/python-AbC123'),exe=path.join(rt,'bin/python3'),pins=path.join(root,'.grave/pins'),before=fs.readdirSync(pins),plan=planned(bankPure,['plot-pure'],exe);
 fs.mkdirSync(path.join(root,'.grave/tombstones'));fs.writeFileSync(path.join(root,'.grave/tombstones/python-AbC123.json'),JSON.stringify({path:rt,reason:'test',at:new Date().toISOString()}));
 let e=rejects(()=>assembleFromBank({root,bank:bankPure,plan,target:exe,id:'tomb'}),'PIN');assert.equal(e.retryable,true);
 assert.deepEqual(fs.readdirSync(pins),before);assert.ok(!fs.readdirSync(path.join(root,'.grave/objects')).some(n=>n.startsWith('tomb-')));assert.ok(!fs.existsSync(path.join(root,'.grave/.lock')));
 fs.rmSync(path.join(root,'.grave/tombstones'),{recursive:true});let o=assembleFromBank({root,bank:bankPure,plan,target:exe,id:'tomb'});assert.deepEqual(fs.readdirSync(pins),before);assert.equal(o.reused,false);
 assert.equal(py(exe,o.path,'import plot_pure;print(plot_pure.VERSION)'),'1.0');
},SHALLOW);

await test('seed capability recipe executes the assembler into its own stage from a plan-wheels plan (main.js provision, -I -S import)',async()=>{
 let root=dir('seed'),planFile=path.join(dir('plans'),'seed.json');fs.writeFileSync(planFile,ok(run(node,[module,'plan-wheels','--bank',bank,'--python',rtpy,'plot-sample==2.0'])));
 fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify({id:'assembler-seed',hosts:['node'],execution:'trusted',permissions:{spawn:true},capabilities:{layer:{install:[{cmd:node,args:[module,'assemble','--into','${stage}','--bank',bank,'--plan',planFile,'--python',rtpy]}]}},environment:{use:['layer']},steps:[]}));
 let t=performance.now(),view=await openPlot(root).provision('default');timings.seed_recipe_provision_ms=ms(t);let L=view.assets.layer.path;
 assert.equal(py(rtpy,L,'import plot_sample;print(plot_sample.VERSION)'),'2.0');let m=read(path.join(L,'.plot-assembly.json'));assert.equal(m.site,L);assert.equal(m.wheels[0].file,'plot_sample-2.0-py3-none-any.whl');
 assert.equal(openPlot(root).view('default').assets.layer.path,L);
},SHALLOW);

let corpus=dir('corpus');
await test('cartographer plan over a dir + tgz corpus: nested placement, integrity, bins; one component object per npm name@version; refusals',()=>{
 let a=path.join(corpus,'a');fs.mkdirSync(a);fs.writeFileSync(path.join(a,'package.json'),JSON.stringify({name:'a',version:'1.2.0',main:'index.js',dependencies:{d:'^1'}}));fs.writeFileSync(path.join(a,'index.js'),"module.exports='a+'+require('d')\n");
 fs.writeFileSync(path.join(corpus,'d-1.0.1.tgz'),tar([{name:'package/package.json',data:JSON.stringify({name:'d',version:'1.0.1',bin:{d:'bin/d.js'}})},{name:'package/index.js',data:"module.exports='d1'\n"},{name:'package/bin/d.js',data:'#!/usr/bin/env node\n',mode:0o755}]));
 fs.writeFileSync(path.join(corpus,'d-2.0.0.tgz'),tar([{name:'package/package.json',data:JSON.stringify({name:'d',version:'2.0.0'})},{name:'package/index.js',data:"module.exports='d2'\n"}]));
 let plan=planClosure({corpus,requested:['a@^1','d@^2']});assert.equal(plan.ok,true,JSON.stringify(plan.diagnostics));
 let root=dir('closure'),t=performance.now(),o=assembleFromBank({root,bank:corpus,plan,id:'closure'});timings.closure_assemble_ms=ms(t);
 assert.equal(ok(run(node,['-e',"console.log(require('./node_modules/a'),require('./node_modules/d'))"],{cwd:o.path})),'a+d1 d2');
 let nested=o.npm.find(n=>n.id==='d@1.0.1');assert.equal(nested.placement,'node_modules/a/node_modules/d');assert.equal(fs.statSync(path.join(o.path,nested.placement,'bin/d.js')).mode&0o777,0o755);
 let comps=o.npm.map(n=>n.component);assert.equal(new Set(comps).size,3);assert.deepEqual(JSON.parse(o.key)[2],[...comps].sort());
 for(let n of o.npm){let v=read(path.join(n.component,'.plot.json')),k=JSON.parse(v.key);assert.deepEqual(k[0].component,{ecosystem:'npm',name:n.name,version:n.version});assert.deepEqual(k[1],[process.platform,process.arch]);assert.equal(v.kind,'component');assert.ok(fs.existsSync(path.join(n.component,'package.json')))}
 let n=0,bad=(mut,code,re)=>{let p=structuredClone(plan);mut(p);let r=dir('closure-bad',''+(++n));rejects(()=>assembleFromBank({root:r,bank:corpus,plan:p,id:'closure'}),code,re);noGrave(r)};
 let at=k=>plan.nodes.findIndex(x=>x.id===k);
 bad(p=>{p.ok=false;p.diagnostics=[{code:'missing',detail:'x'}]},'PLAN',/not ok/);
 bad(p=>{p.nodes[at('d@1.0.1')].source.integrity='sha512-'+createHash('sha512').update('other').digest('base64')},'INTEGRITY',/integrity mismatch/);
 bad(p=>{p.nodes[at('a@1.2.0')].placement='node_modules/../../x'},'PLAN',/invalid placement/);
 bad(p=>{p.nodes[at('a@1.2.0')].source.path=base},'PLAN',/source outside bank/);
 bad(p=>{p.nodes[at('d@2.0.0')].version='2.0.1'},'METADATA',/does not match plan/);
 bad(p=>{p.target.arch='not-'+process.arch},'PLAN',/is not this host/);
 return {placements:o.npm.length};
});

await test('BANK_CHANGED: reuse re-verifies recorded wheel and npm digests and refuses changed bank bytes under unchanged names',()=>{
 let wb=dir('banks','changing'),file=wheel(wb,{name:'plot-shift',files:{'plot_shift.py':'V=1\n'}}),root=dir('changing');
 let o=assembled(root,wb,['plot-shift'],'shift');assert.equal(assembled(root,wb,['plot-shift'],'shift').reused,true);
 wheel(wb,{name:'plot-shift',files:{'plot_shift.py':'V=2\n'}});let e=rejects(()=>assembled(root,wb,['plot-shift'],'shift'),'BANK_CHANGED',/plot_shift-1.0-py3-none-any.whl/);
 assert.equal(e.object,o.path);assert.equal(e.changed[0].ref,'wheel:'+path.basename(file));assert.notEqual(e.changed[0].recorded,e.changed[0].current);assert.equal(fs.readdirSync(path.join(root,'.grave/objects')).length,1);
 let nb=dir('banks','npm-changing'),pkg=path.join(nb,'q');fs.mkdirSync(pkg);fs.writeFileSync(path.join(pkg,'package.json'),JSON.stringify({name:'q',version:'1.0.0'}));fs.writeFileSync(path.join(pkg,'index.js'),'module.exports=1\n');
 let nroot=dir('npm-changing');assembleFromBank({root:nroot,bank:nb,plan:planClosure({corpus:nb,requested:['q@1']}),id:'q'});
 fs.writeFileSync(path.join(pkg,'index.js'),'module.exports=2\n');e=rejects(()=>assembleFromBank({root:nroot,bank:nb,plan:planClosure({corpus:nb,requested:['q@1']}),id:'q'}),'BANK_CHANGED',/npm:q@1.0.0/);
 assert.equal(path.basename(e.object).startsWith('npm-q-'),true);return {policy:'refuse'};
});

const sampled=path.join(base,'tests/fixtures/closure/sample-plan.json');
if(fs.existsSync(sampled)){await test('cartographer sample-plan.json (P07-02) assembled; planClosure --root then marks every node present and reassembly reuses',()=>{
 let plan=read(sampled),srcs=plan.nodes.map(n=>n.source?.path).filter(Boolean);assert.ok(srcs.length,'sample plan has sources');
 let common=srcs.map(s=>path.dirname(s)).reduce((a,b)=>{while(!(b+path.sep).startsWith(a+path.sep))a=path.dirname(a);return a});
 let root=dir('cartographer'),before=tree(common),o=assembleFromBank({root,bank:common,plan,id:'cartographer'});assert.deepEqual(tree(common),before,'corpus unmodified');
 assert.deepEqual(o.npm.map(n=>n.id),plan.order.filter(id=>plan.nodes.find(n=>n.id===id).ecosystem==='npm'));
 for(let n of plan.nodes.filter(n=>n.ecosystem==='npm'))assert.equal(read(path.join(o.path,n.placement,'package.json')).version,n.version);
 let r=run(node,[cartographer,'plan','--corpus',common,'--root',root,...plan.requested]);let again=JSON.parse(ok(r));assert.equal(again.ok,true);
 for(let n of again.nodes){assert.ok(n.present.object,'not present: '+n.id);assert.equal(path.dirname(n.present.object),path.join(root,'.grave/objects'));assert.deepEqual(JSON.parse(n.present.key)[0].component,{ecosystem:'npm',name:n.name,version:n.version})}
 let re=assembleFromBank({root,bank:common,plan:again,id:'cartographer'});assert.equal(re.reused,true);assert.equal(re.path,o.path);
 return {nodes:plan.nodes.length,present:again.nodes.length,bank:common};
})}else console.log('NOT RUN cartographer sample-plan.json integration: tests/fixtures/closure/sample-plan.json absent');

const ownedPy=process.env.PLOT_TEST_OWNED_PYTHON;
if(ownedPy){await test('C extension importable by the owned runtime named by PLOT_TEST_OWNED_PYTHON',()=>{
 assert.ok(path.isAbsolute(ownedPy),'PLOT_TEST_OWNED_PYTHON must be absolute');
 let [exe,basePrefix,include,ext]=JSON.parse(ok(run(ownedPy,['-I','-c','import sys,sysconfig,json,os;print(json.dumps([os.path.realpath(sys.executable),os.path.realpath(sys.base_prefix),sysconfig.get_path("include"),sysconfig.get_config_var("EXT_SUFFIX")]))'])));
 const under=p=>/\/\.grave\/(objects|host)\//.test(p+'/');
 if(!under(fs.realpathSync(ownedPy))&&!under(ownedPy)||!under(exe)||!under(basePrefix))throw Error(`not an owned runtime: path ${ownedPy}, executable ${exe}, base_prefix ${basePrefix} must lie under .grave/objects or .grave/host`);
 if(!fs.existsSync(path.join(include,'Python.h')))throw Error('fixture prerequisite missing: owned runtime has no Python.h at '+include);
 let at=dir('owned'),c=path.join(at,'native.c'),built=path.join(at,'plot_native'+ext);fs.writeFileSync(c,NATIVE_C);ok(run('cc',['-shared','-fPIC','-I'+include,c,'-o',built]));
 let id=targetIdentity(ownedPy),tag=`${id.abi}-${id.abi}-${id.platforms.at(-1)}`,ob=dir('banks','owned');wheel(ob,{name:'plot-native',tag,purelib:false,files:{['plot_native'+ext]:fs.readFileSync(built)},modes:{['plot_native'+ext]:0o100755}});
 let o=assembled(dir('owned-root'),ob,['plot-native'],'native',ownedPy);assert.equal(py(ownedPy,o.path,'import plot_native;print(plot_native.value())'),'37');
 return {python:ownedPy,version:id.version,soabi:id.soabi};
},OWNED)}else console.log('owned-runtime: NOT RUN (pending P07-09/P07-07 composition)');

try{chmodTree(bank,true)}catch{}
fs.rmSync(tmp,{recursive:true,force:true});
const passed=checks.filter(c=>c.passed).length,labels=[...new Set(checks.map(c=>c.runtime).filter(Boolean))];
console.log('runtime labels '+JSON.stringify(Object.fromEntries(labels.map(l=>[l,checks.filter(c=>c.runtime===l).length]))));
console.log('timings '+JSON.stringify(timings));
console.log(`${passed}/${checks.length} assembler checks`);
if(passed!==checks.length)process.exitCode=1;
