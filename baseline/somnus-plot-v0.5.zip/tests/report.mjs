import * as fs from 'node:fs';
import path from 'node:path';
const base=path.resolve(new URL('..',import.meta.url).pathname);
const test=JSON.parse(fs.readFileSync(path.join(base,'evidence/integration.json')));
const bench=JSON.parse(fs.readFileSync(path.join(base,'evidence/benchmark.json')));
const fmt=n=>n.toFixed(3);
const labels={new_persisted_cached_asset_view:'New persisted view, acquired assets',cached_reprovision:'Reprovision an existing view',view_lookup:'Load and check an existing view',cli_warm_provision:'Fresh Node CLI + cached-assets provisioning',cli_python_package_execution:'Fresh CLI + Python/package execution',raw_python_startup:'Raw Python startup, no view/package imports',empty_venv_without_pip:'Empty venv creation, no pip or package set'};
let text=`# Flashback Stage 1 — measured results

Date: ${test.finished_at.slice(0,10)}. **${test.passed}/${test.total} integration checks pass**.
Complete shipped core: **${test.core_bytes.toLocaleString('en-US')} bytes**, within
the original 9,063-byte bundle ceiling. No mandatory external adapter or npm dependency.

This stage delivers dependency/host-aware acquisition, reuse of owned resources,
atomic environment-view activation, version-specific package layers and separate
writable state. It establishes a tested alternative to creating one Python venv
per environment for the covered execution modes.

## Timing

Host: ${bench.environment.os}/${bench.environment.arch}, ${bench.environment.node},
${bench.environment.python}, ${bench.environment.cpu}. Container scratch filesystem;
warm local assets and filesystem cache. The result is host-specific.

| Operation | Samples | p50 ms | p95 ms | p99 ms | Maximum ms |
|---|---:|---:|---:|---:|---:|
`;
for(let [name,{summary:s}] of Object.entries(bench.metrics))text+=`| ${labels[name]} | ${s.n} | ${fmt(s.p50_ms)} | ${fmt(s.p95_ms)} | ${fmt(s.p99_ms)} | ${fmt(s.max_ms)} |\n`;
text+=`
Cold first acquisition of the runtime, two real wheels, dependency data and
analysis capability took **${fmt(bench.cold_first_acquisition_ms)} ms** in one run.
This is one observation, not a percentile. No download was involved.

The new-view series creates **1,000 distinct persisted views**, each with its own
writable directory, referencing the same four acquired assets. Descriptors were
${bench.workload.descriptor_bytes_min}–${bench.workload.descriptor_bytes_max} bytes.
The measured API operation includes manifest read, selected DAG/host planning,
resource availability checks, exclusive writer lock, state-directory creation,
descriptor serialization, **file fsync and atomic rename**. It excludes acquisition,
resolver work and child-process launch. Seed and measured views 0/499/999 then
execute Python imports, an actual compiled extension, package metadata and the
dependency dataset, writing their own verified output.

**The persisted cached-view p95 gate is below 6 ms. The full fresh-process
provisioning/execution target remains open.** The difference is recorded rather
than relabeled as a completed installation. Fresh Node startup, interpreter startup,
cold resolution and disk acquisition need their own subsequent work.

The empty-venv measurement is a runtime-only reference with no pip and none of the
view workload's packages or other capabilities. It is not an equivalent end-to-end
environment comparison. No speedup claim against uv or another installer is made.

Parent-directory fsync/power-loss durability is not implemented. Artifact integrity
is not rescanned during warm provisioning. Windows, macOS, Termux and browser
execution are not validated by these Linux results.

## Executed integration checks

`;
for(let v of test.checks)text+=`- ${v.name}: ${v.passed?'PASS':'FAIL'}\n`;
text+=`
Archive testing includes real local CPython extraction and adversarial fixtures.
The CPython archive was reconstructed from the host's actual interpreter and
standard library; dynamic OS libraries remain host dependencies. This does not
establish compatibility with a downloaded standalone distribution.

## Included evidence

- integration.json, integration.log: actual checks and output.
- benchmark.json: environment, sample counts, percentiles, every raw timing,
  workload and explicitly scoped performance gates.
- benchmark.log: concise output from the same run.
- package-smoke.json: runnable clean-package smoke check, added when packaging.

Reproduce with node build.mjs, node tests/integration.mjs,
node tests/benchmark.mjs, and node tests/report.mjs.
The source, contract and supplied audit baseline accompany this evidence.
`;
fs.writeFileSync(path.join(base,'evidence/RESULTS.md'),text);
console.log(JSON.stringify({integration:[test.passed,test.total],core_bytes:test.core_bytes,new_view_p95_ms:bench.metrics.new_persisted_cached_asset_view.summary.p95_ms,cli_provision_p95_ms:bench.metrics.cli_warm_provision.summary.p95_ms}));
