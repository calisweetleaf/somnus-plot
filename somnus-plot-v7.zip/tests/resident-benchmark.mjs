// Timings include actual sockets, persisted descriptors, workers and captured output.
// No synthetic work substituted for acquisition or execution. Every sample is kept.
import * as fs from 'node:fs';
import * as path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {openPlot} from '../main.js';
import {start,request} from '../capabilities/resident.mjs';
const base=path.resolve(new URL('..',import.meta.url).pathname),core=path.join(base,'main.js'),module=path.join(base,'capabilities/resident.mjs'),node=process.execPath;
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'plot-resident-bench-')),root=path.join(tmp,'plot');fs.mkdirSync(root);fs.mkdirSync(path.join(root,'capabilities'));fs.copyFileSync(module,path.join(root,'capabilities/resident.mjs'));
const manifest={hosts:['node'],execution:'trusted',permissions:{spawn:true},capabilities:{resident:{install:[{cmd:node,args:['-e',"require('node:fs').copyFileSync(process.argv[1],'resident.mjs')",path.join(root,'capabilities/resident.mjs')]}]},data:{install:[{cmd:node,args:['-e',"require('node:fs').writeFileSync('values.json','[11,23,37,43]')"]}]}},environment:{use:['data']}};fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify(manifest));
const stats=a=>{const s=a.slice().sort((a,b)=>a-b),q=n=>s[Math.ceil(n*s.length)-1];return {n:s.length,p50_ms:q(.5),p95_ms:q(.95),p99_ms:q(.99),max_ms:s.at(-1),mean_ms:s.reduce((a,b)=>a+b,0)/s.length}};
async function measure(n,fn){const a=[];for(let i=0;i<n;i++){const t=performance.now();await fn(i);a.push(performance.now()-t)}return {summary:stats(a),samples_ms:a}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const child=args=>new Promise((resolve,reject)=>{const c=spawn(node,args,{stdio:['ignore','pipe','pipe']});let stdout='',stderr='';c.stdout.on('data',b=>stdout+=b);c.stderr.on('data',b=>stderr+=b);c.on('error',reject);c.on('close',code=>code?reject(Error(stderr)):resolve(stdout))});
let endpoint;
try{
 const started=new Date().toISOString(),plot=openPlot(root),t0=performance.now();const seed=await plot.provision('seed');const coldData=performance.now()-t0;
 let t=performance.now();await plot.provision('_resident',{use:['resident']});const coldResident=performance.now()-t;
 t=performance.now();endpoint=await start(root,core);const serviceStart=performance.now()-t;
 for(let i=0;i<20;i++)await request(endpoint,{op:'provision',name:'warm-'+i});
 const directViews=await measure(1000,i=>plot.provision('direct-'+i));
 const metrics={direct_persisted_cached_view:directViews,resident_ping:await measure(300,()=>request(endpoint,{op:'ping'})),resident_persisted_cached_view:await measure(300,i=>request(endpoint,{op:'provision',name:'rpc-'+i})),raw_node_child_startup:await measure(40,()=>child(['-e','process.stdout.write("started")']))};
 const submissions=[],workerLaunch=[],complete=[],reconnect=[],results=[];
 for(let i=0;i<40;i++){
  const begin=performance.now();const job=await request(endpoint,{op:'submit',name:'seed',steps:[{cmd:node,needs:['data'],args:['-e',"const fs=require('node:fs'),v=JSON.parse(fs.readFileSync(process.argv[1]));if(v.reduce((a,b)=>a+b,0)!==114)process.exit(9);fs.writeFileSync(process.env.PLOT_STATE+'/result-'+process.argv[2],'114');console.log('114')",'${cap:data}/values.json',String(i)]}]});const accepted=performance.now();submissions.push(accepted-begin);
  const dir=path.join(root,'.grave/resident/jobs',job.id);let marked=false,final;const deadline=Date.now()+10000;
  while(Date.now()<deadline){if(!marked&&fs.existsSync(path.join(dir,'control.json'))){workerLaunch.push(performance.now()-accepted);marked=true}let status;try{status=JSON.parse(fs.readFileSync(path.join(dir,'status.json')))}catch{}if(status&&['succeeded','failed'].includes(status.state)){final=status;break}await sleep(1)}
  assert.equal(final?.state,'succeeded');complete.push(performance.now()-begin);t=performance.now();const status=await request(endpoint,{op:'inspect',id:job.id});reconnect.push(performance.now()-t);assert.equal(status.state,'succeeded');const out=await request(endpoint,{op:'output',id:job.id});assert.equal(out.text,'114\n');assert.equal(fs.readFileSync(path.join(seed.state,'result-'+i),'utf8'),'114');results.push(job.id);
 }
 for(const [k,v] of Object.entries({resident_durable_submit:submissions,accepted_to_worker_control_ready:workerLaunch,complete_submit_through_verified_child_exit:complete,resident_terminal_inspect:reconnect}))metrics[k]={summary:stats(v),samples_ms:v};
 assert.equal(workerLaunch.length,40);
 // Execute views from both timing series, after measurement, against their exact resources.
 for(const name of ['direct-0','direct-499','direct-999','rpc-0','rpc-299']){const v=plot.view(name);assert.equal(v.assets.data.path,seed.assets.data.path);assert.equal(await plot.run(name,[{cmd:node,args:['-e',"const fs=require('node:fs');if(JSON.parse(fs.readFileSync(process.argv[1])).length!==4)process.exit(1);fs.writeFileSync(process.env.PLOT_STATE+'/verified','yes')",'${cap:data}/values.json']}]),0)}
 const report={started_at:started,finished_at:new Date().toISOString(),environment:{platform:process.platform,arch:process.arch,node:process.version,release:os.release(),cpu:os.cpus()[0]?.model,filesystem:'scratch under '+os.tmpdir()+', warm local cache',core_bytes:fs.statSync(core).size,optional_resident_bytes:fs.statSync(module).size},cold_acquisition:{native_data_ms:coldData,optional_resident_ms:coldResident,observations:1,network:false},resident_startup_ms:serviceStart,metrics,verified_job_ids:results,gates:{direct_cached_view_p95_under_6_ms:directViews.summary.p95_ms<6,resident_cached_view_p95_under_6_ms:metrics.resident_persisted_cached_view.summary.p95_ms<6},scope:{resident_persisted_cached_view:'Fresh TCP connection, authentication, selected DAG and marker checks, authoritative core provisioning, state mkdir, file fsync, rename and response. No acquisition or child launch.',resident_durable_submit:'Fresh TCP connection, spec resolution, private durable submission, detached worker spawn acknowledgement, response. Excludes worker initialization and tenant execution.',accepted_to_worker_control_ready:'Observed from submit response to private worker endpoint record. Includes worker process startup; 1 ms file polling adds measurement overhead. It is not raw child startup.',complete_submit_through_verified_child_exit:'Submission through worker terminal metadata and captured child exit, including real Node dataset computation and output/state writes. 1 ms polling overhead included; output correctness checked after timing.',raw_node_child_startup:'spawn through exit/stdout drain for an independent Node child; no view or resident worker.',resident_ping:'Fresh TCP connection through authentication and response; no job or view operation.'},limits:['Host-specific warm filesystem measurements, not hardware-independent guarantees.','Cold acquisitions are single offline observations, without network/resolver latency.','No full-system reboot/power-loss durability test. Core fsyncs files, not parent directories.','Worker pool reuse is not implemented: each job starts an independent Node worker and tenant process.','Benchmarks run sequentially after integration; percentiles retain outliers without trimming.']};
 fs.writeFileSync(path.join(base,'evidence/resident-benchmark.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({...report,metrics:Object.fromEntries(Object.entries(metrics).map(([k,v])=>[k,v.summary])),verified_job_ids:results.length},null,2));
 // Both measured objectives remain gates; no full-execution <6 ms claim.
 if(!Object.values(report.gates).every(Boolean))process.exitCode=1;
}finally{if(endpoint)try{await request(endpoint,{op:'stop'})}catch{}await sleep(50);fs.rmSync(tmp,{recursive:true,force:true})}
