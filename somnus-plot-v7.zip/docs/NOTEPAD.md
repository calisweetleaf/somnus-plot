# Somnus Plot — Execution Ledger

Append-only. Newest entry at the bottom. Never rewrite an earlier entry; correct it with a new one.

Format:

~~~
### YYYY-MM-DD HH:MM TZ — <executor> — <lane>
- Base:
- Did:
- Validation:
- Proof facts:
- Surfaces synchronized:
- Next agent:
- Hazards:
~~~

### 2026-10-20 00:55 CDT — Droid — control plane (P06-CP)
- Base: `main` @ `896f48d` (v0.6.0), clean tracked tree; untracked `docs/Plot-Fable.md` supplied by operator. Repo moved from `LAB/Experiments/projects/somnus-plot` to `Repositories/somnus-plot` on 2026-10-19.
- Did: Installed Accelerate control plane: `AGENTS.md` (router), `TASK.md` (P07-01 DRAFT + v0.7 queue), `docs/CONTEXT.md`, `docs/MEMORY.md`, this ledger, `scripts/gate.sh` (disposable-copy gate; `--bench`; `--evidence`), `.gitignore` (`/.grave/`, `/data.json`). Refreshed `filetree.md`. No source, test, evidence or baseline file changed.
- Validation: `scripts/gate.sh` → `gate: PASS` (65 s). `validate-packet.mjs TASK.md` → PASS. Benchmarks NOT RUN.
- Proof facts: `core_bytes` 9,061 ≤ 9,063; rebuilt `main.js` byte-identical to committed; 18/18 integration; 19/19 resident; package smoke PASS. Host: Linux 7.0.0-38, Node v24.14.0, Python 3.14.4, gcc. `git status` shows no tracked modifications after the gate.
- Surfaces synchronized: `AGENTS.md`, `TASK.md`, `docs/CONTEXT.md`, `docs/MEMORY.md`, `docs/NOTEPAD.md`, `filetree.md`.
- Next agent: Ask the operator to dispatch or reorder P07-01 in `TASK.md`; do not start implementation while it is DRAFT.
- Hazards: Core has 2 bytes of headroom; any `src/plot.mjs` change will likely need `build.mjs` identifier additions or an operator ceiling decision.

### 2026-10-20 12:10 UTC — Droid (Opus 5.5, Keeper/coordinator) — P07-00 contract freeze
- Base: `main` @ `b72a98d` (single commit `.`); docs previously cited `896f48d` and root `/home/daeron/...`, both reconciled. Untracked operator files `.colony/`, `.factory/`, `SWARM.md`, `attachments/` left untouched.
- Did: Placed operator-supplied v0.7 master plan as `PLAN.md` (§7 packet detail moved to `TASK.md`). Wrote `docs/V07-CONTRACTS.md` (contracts v1: durability primitives, global lock order, historical reuse, pins with pin-then-validate, request IDs, prune tombstones, job/standby/env lifecycles, closure schema `plot.closure/1`, bootstrap entry + host matrix, frozen workloads incl. nominal 5 submit/s × 200 s, ownership map). Rewrote `TASK.md` with P07-00..P07-09. Refreshed `AGENTS.md`, `docs/CONTEXT.md`, `filetree.md`.
- Validation: `scripts/gate.sh` → `gate: PASS` (18/18 integration, 19/19 resident, package smoke). Packet validator NOT RUN (`~/.factory/skills/somnus-accelerate` absent on this host).
- Proof facts: core 9,061/9,063; resident 20,708; host Linux 6.1.158+ x64 Xeon 2.60GHz 4 vCPU 7.9 GiB ext4, Node v24.22.0, Python 3.12.3, gcc, git. No Windows/macOS/Termux host available.
- Surfaces synchronized: `PLAN.md`, `docs/V07-CONTRACTS.md`, `TASK.md`, `AGENTS.md`, `docs/CONTEXT.md`, `docs/NOTEPAD.md`, `filetree.md`.
- Next agent: Wave 1 foragers on P07-01, P07-02, P07-03, P07-09 per `TASK.md`.
- Hazards: 2 bytes of core headroom; sustained-submit bell bounded by worker replenishment; second OS family NOT RUN keeps cross-host acceptance open.

### 2026-10-20 13:05 UTC — Droid (Keeper; wore Sentinel; counted the beat with Fletcher's lexicon) — P07-01 landed
- Base: `fc683f8`.
- Did: Landed forager-1's P07-01: historical exact-key reuse (scan `.grave/objects/<k>-*` under L1, zero spawn), `atom` parent-dir fsync + `create` write-once primitive, `exec` stdout fallback, `pip:false` + `venv --without-pip` for package-less tenants, mandatory foreground pin in `run()`. Compactor strengthened (collision-free alphabet, `;}` drop, `let` joining, numeric folding) and repeated forms removed from src.
- Validation: Keeper `scripts/gate.sh` → `gate: PASS` (build 9,008/9,063, rebuild identical, 24/24 integration, 19/19 resident, smoke). Keeper Sentinel tastes in scratch copy: rebuild deterministic; `a` vs `a-b` prefix collision cannot cross-adopt (keys differ) and v1 reuse spawned nothing. Second independent Sentinel NOT RUN (operator redirected reviewer use).
- Proof facts: `main.js` 9,008 bytes (55 headroom), `src/plot.mjs` 12,017, `build.mjs` 4,586.
- Decision: accepted `pip:false` one-time key change for package-less Python tenants (contracts v1.2).
- Minor: if two valid objects share a key, selection follows `readdirSync` order (harmless; identical identity).
- Next agent: P07-04 (forager-5, running) may now close its seed-coupled checks.
- Hazards: historical scan is O(objects with prefix) on ledger miss; no index.

### 2026-10-20 13:20 UTC — Droid (Keeper; wore Sentinel) — P07-02 landed
- Base: `2b9b384`.
- Did: Landed forager-2's `capabilities/cartographer.mjs` (31,126 B; `planClosure`, `inspectCorpus`, CLI) + `tests/cartographer.mjs` + generated `tests/fixtures/closure/` (sample plan, 11 nodes, ok:true). Wired `node tests/cartographer.mjs` into `scripts/gate.sh`. Contracts v1.3 records presence rule (`recipe.component={ecosystem,name,version}` + host match), placement-qualified duplicate ids, new fields, fail-closed codes.
- Validation: lane `scripts/gate.sh` PASS; Keeper Sentinel in scratch: 12/12, fixture regeneration byte-stable, CLI byte-identical across runs, no `child_process`/eval/fetch/dynamic import in the module. Lane mutation testing: 7/8 mutants killed (peer-lookup start at own node_modules survived; SALT).
- Proof facts: supported range grammar per contracts §10; unsupported forms reported (tags, git+, npm:, file:, workspace:, URLs, 4-part, `~>`).
- Next agent: P07-03 must stamp `recipe.component` for npm presence and add `planWheels` (Fletcher TEMPO 15).
- Hazards: placement is deterministic hoisting, not npm arborist parity; optional-subtree deep failure fails the plan (stricter than npm).

### 2026-10-20 13:45 UTC — Droid (Keeper; wore Sentinel) — P07-04 landed
- Base: `eef36b8`.
- Did: Landed forager-5's resident work (`capabilities/resident.mjs` 20,708→39,085 B, `tests/resident.mjs` 41,206 B): O(1) reserved admission map built at `serve` start, revisioned `status.json` with fenced reconciler (250 ms / 8 entries / 500 ms probe, off the submit path), worker `done` notification authenticated by supervisor token, `rid` lookup records (`request conflict`, `request expired`), `PLOT_JOB_STATE`/`PLOT_STEP_INDEX`/`PLOT_STEP_OUT`, transitive job pins, pin-safe dry-run/apply prune with tombstone intents and crash recovery, `PLOT_RESIDENT_MAX_ACTIVE`, `launch.json`.
- Validation: Keeper `PLOT_REQUIRE_SEED_COUPLED=1 scripts/gate.sh` → `gate: PASS` (24/24 integration, 32/32 resident, 12/12 cartographer, smoke). Keeper Sentinel: `.kill(` uses only `process.kill(pid,0)` liveness probe and SIGTERM/SIGKILL of the worker's own direct child; no signal is sent to a PID read from a record.
- Decisions (contracts v1.4): job pins released at terminal status; `interrupted` written only by the reconciler and never expired by it; evicted rid leaves an expired marker; completion notify goes to the supervisor recorded in the submission.
- Next agent: P07-05 standby claim (Keeper, per operator 2026-10-20: Keeper implements directly).
- Hazards: ALARM 51 open: seed `run()` does not re-check `.grave/tombstones/<obj>.json` after writing its foreground pin (pin-then-validate gap on the seed side; 55 bytes headroom). PERSISTENT-NATIVE.md not yet updated for v0.7 resident ops (P07-08).

### 2026-10-20 13:55 UTC — Droid (Keeper) — P07-09 landed
- Base: `9f6f548`.
- Did: Landed forager-4's host bootstrap: `capabilities/bootstrap.mjs` (37,922 B; inspect/plan/acquire/verify/activate/kit), `bootstrap/plot.sh`, `bootstrap/plot.ps1`, `bootstrap/recipes/{node,python,git,zlib}.json` (official sha256 pins; musl Node from unofficial-builds, labelled), `bootstrap/hosts/README.md` (Windows/macOS/Termux runbooks, NOT RUN). Wired `step bootstrap` into `scripts/gate.sh`.
- Validation: `node tests/bootstrap.mjs` → 21/21 on the reference host, including online official-source checks (network available) and a Node-absent launcher with PATH masked. The suite reports offline checks as NOT RUN when no network and no cache exist.
- Proof facts: kit Node archives are the pinned upstream files (never repacked from the host `node`), which closes Fletcher call 17. Android has no upstream Node/Python build, so the route is operator-supplied `PLOT_NODE`.
- Next agent: P07-05 (Keeper).
- Hazards: the suite downloads about 60 MB into `$TMPDIR/plot-bootstrap-cache` on first run. Windows/macOS/Termux remain NOT RUN.

### 2026-10-20 14:05 UTC — Droid (Keeper) — P07-03 landed
- Base: `7e13d89`.
- Did: Landed forager-3's `capabilities/assembler.mjs` (51,459 B; `verifyWheel`, `installWheels`, `assembleFromBank`, `planWheels`, CLI incl. `plan-wheels`) and `tests/assembler.mjs`. Wired `step assembler` into `scripts/gate.sh`. Contracts v1.5 records the npm component object, the layer `.plot.json` `inputs[]`, and `BANK_CHANGED`.
- Validation: lane `node tests/assembler.mjs` 15/15 (in place and in a disposable copy); lane `scripts/gate.sh` PASS. Every installing check consumes a code-emitted plan; runtime labels `{"shallow-host":8}`; owned-runtime check NOT RUN (`PLOT_TEST_OWNED_PYTHON` unset).
- Next agent: P07-05 (Keeper, in progress); P07-07 composes assembler with bootstrap-acquired Python for the `owned` label.
- Hazards: markers in `Requires-Dist` are recorded unsupported, not evaluated; glibc Linux wheel tags only; case-only path collisions not detected; an acquisition pin from a killed writer awaits reconciler release.

### 2026-10-20 14:50 UTC — Droid (Keeper implemented; wore Sentinel after code) — P07-05 landed
- Base: `c323f7d`.
- Did: Standby claim and sustainable capacity in `capabilities/resident.mjs` (39,085→~47,900 B). Single-use standby workers (`--standby <root> <slot>`) record `standby/<slot>/standby.json`, warm their claim path on scratch files, announce `ready`, and retire on `shutdown`, supervisor instance change, or 5 s unreachable. The claim RPC writes one write-once `claimed.json` (owner, rid, rotated control endpoint) before replying. Supervisor pool: ready 2 / maxStarting 2 / maxWaiting 16 (`PLOT_RESIDENT_READY`, `PLOT_RESIDENT_MAX_STARTING`, `PLOT_RESIDENT_MAX_WAITING`); lease decided synchronously before durable acceptance; reply `{claimed, determinate, instance, path:standby|cold|waited, t:{reserved,published,durable,claimed,replied}}`. Lost ACK adopts `claimed.json`; a second worker is tried only when the first is proven gone without a claim; three proven-gone attempts fence the job `interrupted`; a live, silent standby gives `determinate:false` and keeps capacity. Restart reconciliation removes dead standby records and dispatches published, never-claimed jobs. `submission.json` and the rid record fsync on the libuv pool, overlapping the claim RPC; the reply waits for them.
- Validation: `PLOT_REQUIRE_SEED_COUPLED=1 scripts/gate.sh` → `gate: PASS` (24/24, 41/41 resident, 12/12, 15/15 assembler, 21/21 bootstrap (online checks ran), smoke). Nine new resident checks: durable claim before reply; supervisor SIGKILL right after reply; crash injection before-claimed (retried 1, succeeded) / after-claimed and after-status (adopted, interrupted, no second worker); lost ACK adopted; duplicate simultaneous rid → 1 job; bursts 2/8/16/32 (32 → 16 accepted, 16 retryable capacity; peakStarting 2); idle expiry 5.0 s after supervisor SIGKILL and clean stop; orphan dispatch after restart; preliminary warm submit-and-claim p50 3.87 / p95 5.04 / p99 7.54 ms (n=120, all `standby`).
- Sentinel (after code): only new signal is the test-only self-SIGKILL hook (`PLOT_TEST_CLAIM_CRASH`, requires a fresh marker file); standby adoption requires the spawned pid, this supervisor's instance and a live identity.
- Decisions (contracts v1.6): see §14.
- Next agent: P07-06 resident environments.
- Hazards: preliminary p95 margin ~1 ms on this host; p99 above 6 ms. The sustained Poisson row (P07-08) is not yet measured. A power loss between the overlapped fsyncs and the reply is not tested (no device).

### 2026-10-20 15:40 UTC — Droid (Keeper implemented; Sentinel after code) — P07-06 landed
- Base: `89f924e`. Correction to the P07-05 entry: resident was 49,563 B after P07-05, not ~47,900.
- Did: Resident execution environments inside `capabilities/resident.mjs` (now 69,478 B): supervisor ops `activate`, `interact`, `env_inspect`, `deactivate`; one detached Environment Host per incarnation (`--env-host`) that owns the env pin and its tenants; Python tenant (view interpreter, `-I -S -u`, persistent globals, last-expression result) and Node tenant (`--tenant-node`, `vm.runInThisContext`, `__plot_session__`, `__plot_assets__`, `require`) as direct children with u32+JSON frames on fd 3; fd 1/2 captured per turn up to 1 MiB with raw end-of-turn markers so `os.write(1)`, replaced `sys.stdout` and late output are attributed correctly; 1 in flight + 8 queued, overflow `busy`; turn rid records and outcome records under the incarnation; `exec` turns; deadlines kill the tenant and retire the incarnation `interrupted`/`lost`; host death proven by identity and fenced; tenants exit on fd-3 EOF. New `tests/resident-env.mjs` (21 checks), wired into `scripts/gate.sh` and its `--evidence` list.
- Validation: `PLOT_REQUIRE_SEED_COUPLED=1 scripts/gate.sh` → `gate: PASS` (24/24, 41/41 resident, 21/21 resident-env, 12/12, 15/15, 21/21, smoke).
- Proof facts: preliminary warm turns (n=200, quiet run): Python native call p50 2.64 / p95 3.44 ms; Node session + acquired package p50 2.54 / p95 3.23 ms.
- Decision: the resident suite's warm submit-and-claim check measured p95 11.6 ms under full-gate load vs 5.0–6.6 ms quiet; it now reports always and asserts only with `PLOT_ASSERT_LATENCY=1`. The frozen 6 ms rows are asserted by the quiet-host benchmark (P07-08).
- Next agent: P07-07 integration.
- Hazards: Node turns share one event loop, so a turn's timers outlive it (by design: the heap persists). Python `SystemExit` inside a turn is reported `failed`, not exit. Env pin ref uses `<name>.<incarnation>` (file-name safe) instead of `<name>/<incarnation>`.

### 2026-10-20 16:30 UTC — Droid (Keeper implemented; Sentinel after code) — P07-07 landed
- Base: `fcdd1f0`.
- Did: New `tests/e2e.mjs` (12 checks, runtime label `owned` on every check; host python3 never used). It deploys the seed into a fresh root. Bootstrap acquires Node 24.22.0 and CPython 3.12.15 from the offline kit into `<root>/.grave/host`. The native wheel is compiled against the owned headers. `planWheels` and the cartographer emit both plans. Seed recipes run the assembler `--into ${stage}` over the owned venv (no pip). Jobs and environments on the deployed resident under the owned Node consume both layers. Crash injection covers seed publication (SIGKILL mid-install, then recovery archives the lock and the stage is never adopted), standby claim (after-claimed: adopted, interrupted, no second worker), activation (supervisor SIGKILL while the host starts: one live host, earlier heap survives), turn completion before and after the outcome record, and prune at `intents` and `moved`. `capabilities/resident.mjs` (70,243 B) gains a shared `crashHook`, test-only `PLOT_TEST_TURN_CRASH` and `PLOT_TEST_PRUNE_CRASH`, and rid lookup for turns on a retired incarnation (contracts v1.8). `tests/package-smoke.mjs` now deploys all four capabilities plus `bootstrap/` and runs bootstrap inspect, cartographer plan and assembler publish from a foreign cwd. Host runners `bootstrap/hosts/certify.sh` and `certify.ps1` were added. `scripts/gate.sh` now runs `step e2e` and lists e2e in `--evidence`. `filetree.md` was refreshed.
- Validation: `PLOT_REQUIRE_SEED_COUPLED=1 scripts/gate.sh` → `gate: PASS` (24/24, 41/41, 21/21 resident-env, 12/12, 15/15, 21/21, 12/12 e2e, smoke). `PLOT_KIT=/tmp/plot-bootstrap-kit PLOT_OFFLINE=1 sh bootstrap/hosts/certify.sh <out> --quick` on the reference host: every step exit 0 under the acquired Node (runner check only, not a cross-host result). `certify.ps1` NOT RUN (no PowerShell host).
- Sentinel (after code): the only new signals are self-SIGKILLs behind fresh-marker test hooks; no signal goes to a PID read from a record.
- Host matrix: Linux x64 glibc RUN; Windows, macOS, Android/Termux and fresh container NOT RUN. Cross-host acceptance stays open.
- Next agent: P07-08 measurements, whitepaper, release.
- Hazards: e2e needs the offline kit (`$TMPDIR/plot-bootstrap-kit` or the cache) and `cc`; without either, it records NOT RUN. After a killed seed provision or prune, the suite calls `recover()` explicitly to archive the dead writer's lock; it does not test whether a live supervisor would reclaim that lock on its own.

### 2026-10-20 17:40 UTC — Droid (Keeper implemented; Sentinel after code) — P07-08 landed
- Base: `dca7cb2`.
- Did: New `tests/v07-benchmark.mjs` measures every frozen contracts §12 row into `evidence/v07-benchmark.json` (warm = pool idle ≥ 2 and starting 0; control-ready = durable `claimed.json` endpoint record, endpoint first answer reported with no gate; seeded Poisson 10/s with pool-empty validity; saturation 5→40/s; bursts; cold/full rows; `PLOT_BENCH_QUICK=1` harness mode). `tests/report.mjs` rewritten for v0.7 (all suites, frozen-workload and gate tables). Wired into `scripts/gate.sh --bench` and `--evidence`. Version 0.7.0 in `package.json`, `manifest.json`, README, STAGE-1, PERSISTENT-NATIVE. `WHITEPAPER.md` v1.0 candidate: abstract, every DESIGN tag resolved to its landing commit, host disclosure, §7.2 aligned with contracts v1.1, §7.3 tables copied from evidence, reproduction record, App C open items O-10..O-17. Contracts v1.9 (benchmark definitions). Router, CONTEXT, TASK, filetree refreshed. Corrected the stale "parent-directory fsync not implemented" wording in `tests/report.mjs` (RESULTS regenerated) and `tests/benchmark.mjs` (JSON keeps the old string until the next `--evidence` run).
- Validation: `scripts/gate.sh --bench` PASS; `scripts/gate.sh --evidence` PASS (146/146; evidence regenerated in place, reviewed); final `PLOT_REQUIRE_SEED_COUPLED=1 scripts/gate.sh` → `gate: PASS` (24/24, 41/41, 21/21 resident-env, 12/12, 15/15, 21/21, 12/12 e2e, smoke). Fletcher not summoned for this packet (operator: Keeper implements directly).
- Proof facts (p95 ms): view lookup 0.131; mixed cached view 3.612; resident cached-view RPC 4.293; multi_version_switch 4.701 (0 spawns); durable submit-and-claim reply 5.933, claim record 5.990, endpoint first answer 16.805; warm Python 3.829 (shallow host), Node 3.620; sustained 10/s Poisson 1,200/1,200 accepted, 0 failures, successful p95 40.536 (FAIL), paths standby 1,035 / waited 146 / cold 19, 165 empty leases; saturation max stable 25/s; cold worker 76.9; complete job 72.9; cold acquisition 33.4; replenish 105.0; bootstrap_cold 3,176.6. Load average at start 1.59.
- Sentinel (after code): no new kill sites; no tokens in evidence or docs.
- Next agent: none queued. Operator decisions: Law 12 single-record reading (O-10), horizon wording (O-4). Candidate next packet: sustained admission p95 (pool sizing or faster worker birth) on the unchanged frozen workload.
- Hazards: durable rows pass by < 0.1 ms on a non-idle host; non-Linux and fresh container NOT RUN; power loss untested; ALARM 51 (seed `run()` tombstone check) open.

### 2026-10-22 03:10 CDT — Droid (Opus 5.5) — v0.7 closeout
- Base: `7c266f1` (v0.7.0 integrated candidate). Operator files under `.factory/skills/code-fable/`, `SWARM.md`, root `Plot-Fable.md` left untouched.
- Did: O-15/ALARM 51 fixed in `src/plot.mjs`: `run()` checks `.grave/tombstones/<obj>.json` intents after the synced foreground pin and fails `tombstoned`; pin file now `foreground-<pid>-<hrtime ns>.json` to fit the ceiling (9,061 B). Integration "foreground pin" check asserts no step spawns against a tombstoned object. Fresh Debian 12 container certification (`certify.sh`, Node absent) found three test-only defects, all fixed: assembler ABI test assumed host Python is not cp311; assembler sample-plan test depended on the writing host's absolute corpus path (now rebased); resident acquisition test polled atom temp files. `tests/v07-benchmark.mjs` adds `sustained_submit_tuned` (4/4 pool, same schedule, no gate) and Linux supervisor VmHWM; `tests/report.mjs` renders both and the container host row. Contracts v1.10. Record archived at `bootstrap/hosts/records/linux-x86_64-debian12-container-20261022T074031Z/`.
- Validation: `PLOT_REQUIRE_SEED_COUPLED=1 scripts/gate.sh` → PASS before evidence; `scripts/gate.sh --evidence` → PASS (146/146, smoke PASS, v07 run valid 07:48–07:58Z). Container: 14/14 steps exit 0, gate PASS.
- Proof facts (p95 ms, new host Ryzen 5 5625U × 12 bare metal, Node v24.14.0): view lookup 0.159; mixed cached view 0.399; resident RPC 0.706; multi_version_switch 0.481 (0 spawns); submit-and-claim reply 3.183 / claim record 3.221; warm Python 0.956, Node 0.806; sustained (2/2) 14.922 FAIL with 1,106 standby / 83 waited / 11 cold; tuned (4/4) 4.572; saturation max stable 40/s; supervisor RSS 74,776 KiB (101,900 after saturation). O-11 diagnosis (scratch harness): standby birth ≈ 42 ms (Node boot + eval 26, setup 7, warm-up 6); deferring warm-up and early replenish did not move p95.
- Decision (operator, 2026-10-22): v0.7 closed by acceptance with named exceptions O-11, O-12 (other OS families), O-13 (power loss), O-10 (Law 12 single-record reading accepted). Horizon numbering deferred; v0.7 is canon to reuse.
- Surfaces synchronized: AGENTS, TASK, CONTEXT, MEMORY (law 11, lineage), contracts §14, WHITEPAPER v1.1, filetree, README, bootstrap/hosts/README, evidence (generated).
- Next agent: none queued. The next stage takes a new form; start from `docs/Plot-Fable.md` and operator direction.
- Hazards: 2 bytes of core headroom remain; any seed change needs bytes found first. Evidence host changed, so 2026-10-20 and 2026-10-22 numbers are not a speedup comparison. Load average 1.57 at benchmark start.

### 2026-10-22 03:30 CDT — Droid (Opus 5.5) — v0.7 closeout, evidence correction
- Base: closeout working tree above (uncommitted).
- Did: O-18: the v0.6 benchmark generators hard-coded "container scratch" (wrong on bare metal). `tests/benchmark.mjs` and `tests/resident-benchmark.mjs` now record `scratch under <os.tmpdir()>` and a host-neutral `limits[0]`; `tests/report.mjs` prints the recorded filesystem. Evidence regenerated again; this run supersedes the 07:48Z run in the entry above, whose numbers are not evidence of record.
- Validation: `scripts/gate.sh --evidence` → PASS (146/146, smoke PASS, v07 run 08:13–08:23Z valid, load 2.51 at start).
- Proof facts (p95 ms): view lookup 0.170; multi_version_switch 0.495; reply 3.322 / claim record 3.364; warm Python 1.156, Node 0.899; sustained (2/2) 16.365 FAIL (1,105 / 85 waited / 10 cold); tuned (4/4) 6.295, all standby, also above the bell on this non-idle run; saturation max stable 35/s; RSS 75,528 / 102,220 / 76,156 KiB.
- Surfaces synchronized: CONTEXT, TASK, WHITEPAPER (v1.1), RESULTS (generated).
- Next agent: none queued.
- Hazards: run-to-run spread on a non-idle desktop is visible (tuned row 4.572 → 6.295 ms between same-day runs); cite only the evidence files.
